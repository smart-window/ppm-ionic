INSERT INTO `activity` (a_type,uid,title,message) VALUES ('system', '0', 'Software UPDATE', 'Softawre updated successfully');
DELETE FROM `cron` WHERE (`cron`='cron') AND (`cron_action`='cron');