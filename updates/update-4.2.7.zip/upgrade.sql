INSERT INTO `activity` (a_type,uid,title,message) VALUES ('system', '0', 'Software UPDATE', 'Softawre updated successfully');
INSERT INTO `app_lang` (`id`, `lang_id`, `text`) VALUES ('272', '1', 'You dont have any story yet, try uploading one now');
INSERT INTO `app_lang` (`id`, `lang_id`, `text`) VALUES ('271', '1', 'Upload story');
INSERT INTO `app_lang` (`id`, `lang_id`, `text`) VALUES ('270', '1', 'Withdrawal successfully ');
INSERT INTO `app_lang` (`id`, `lang_id`, `text`) VALUES ('269', '1', 'sent you');
INSERT INTO `app_lang` (`id`, `lang_id`, `text`) VALUES ('268', '1', 'You have sent');
INSERT INTO `app_lang` (`id`, `lang_id`, `text`) VALUES ('267', '1', 'Gift');
INSERT INTO `app_lang` (`id`, `lang_id`, `text`) VALUES ('266', '1', 'Close');
INSERT INTO `app_lang` (`id`, `lang_id`, `text`) VALUES ('265', '1', 'Slow down, you are going too fast, view the profiles for a second at least');
INSERT INTO `app_lang` (`id`, `lang_id`, `text`) VALUES ('264', '1', 'Cashout');
INSERT INTO `app_lang` (`id`, `lang_id`, `text`) VALUES ('263', '1', 'New');
INSERT INTO `app_lang` (`id`, `lang_id`, `text`) VALUES ('262', '1', 'View Story');
INSERT INTO `app_lang` (`id`, `lang_id`, `text`) VALUES ('261', '1', 'Stories');
INSERT INTO `app_lang` (`id`, `lang_id`, `text`) VALUES ('260', '1', 'Username');


ALTER TABLE `spotlight` MODIFY COLUMN `photo`  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL AFTER `lng`;