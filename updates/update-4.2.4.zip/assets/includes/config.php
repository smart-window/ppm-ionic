<?php

$db_host = 'localhost';
$db_name = 'bello';
$db_username = 'root';
$db_password = 'password';
$site_url = 'http://localhost/';

