INSERT INTO `activity` (a_type,uid,title,message) VALUES ('system', '0', 'Software UPDATE', 'Softawre updated successfully');

INSERT INTO `plugins_settings` (`plugin`, `setting`, `setting_val`, `title`, `info`, `label`, `block`, `setting_type`, `setting_options`, `orden`, `docs`, `premium`) VALUES ('amazon', 'region', '', 'Amazon S3 Bucket Region', NULL, 'Amazon S3 Bucket Region', 'amazon_general', 'text', NULL, '-1', '0', '0');
INSERT INTO `app_lang` (`id`, `lang_id`, `text`) VALUES ('285', '1', 'You have ');
INSERT INTO `app_lang` (`id`, `lang_id`, `text`) VALUES ('284', '1', 'Type a message');
INSERT INTO `app_lang` (`id`, `lang_id`, `text`) VALUES ('283', '1', 'Done');
INSERT INTO `app_lang` (`id`, `lang_id`, `text`) VALUES ('282', '1', 'Distance');
INSERT INTO `app_lang` (`id`, `lang_id`, `text`) VALUES ('281', '1', 'Location');
INSERT INTO `app_lang` (`id`, `lang_id`, `text`) VALUES ('280', '1', 'Show me');
INSERT INTO `app_lang` (`id`, `lang_id`, `text`) VALUES ('279', '1', 'Current Location');
INSERT INTO `app_lang` (`id`, `lang_id`, `text`) VALUES ('278', '1', 'Current Selection');
INSERT INTO `app_lang` (`id`, `lang_id`, `text`) VALUES ('277', '1', 'Filter');
DELETE FROM `plugins_settings` WHERE (`plugin`='videocall') AND (`setting`='videocallServer');

ALTER TABLE `landing_lang` MODIFY COLUMN `preset`  varchar(55) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL AFTER `text`, DROP PRIMARY KEY, ADD PRIMARY KEY (`id`, `lang_id`, `theme`, `preset`);
INSERT INTO `landing_lang` (`id`, `lang_id`, `theme`, `text`, `preset`, `page`) VALUES ('1', '1', 'landing1', 'Do you already have an account?', 'landing1-155897', NULL);
INSERT INTO `landing_lang` (`id`, `lang_id`, `theme`, `text`, `preset`, `page`) VALUES ('2', '1', 'landing1', 'Enter', 'landing1-155897', NULL);
INSERT INTO `landing_lang` (`id`, `lang_id`, `theme`, `text`, `preset`, `page`) VALUES ('3', '1', 'landing1', 'Chat with new people around the world.', 'landing1-155897', NULL);
INSERT INTO `landing_lang` (`id`, `lang_id`, `theme`, `text`, `preset`, `page`) VALUES ('4', '1', 'landing1', 'Social discovery website for meeting new people', 'landing1-155897', NULL);
INSERT INTO `landing_lang` (`id`, `lang_id`, `theme`, `text`, `preset`, `page`) VALUES ('5', '1', 'landing1', 'Its faster with social networks', 'landing1-155897', NULL);
INSERT INTO `landing_lang` (`id`, `lang_id`, `theme`, `text`, `preset`, `page`) VALUES ('6', '1', 'landing1', 'Join in!', 'landing1-155897', NULL);
INSERT INTO `landing_lang` (`id`, `lang_id`, `theme`, `text`, `preset`, `page`) VALUES ('7', '1', 'landing1', 'A nice opportunity to make both friendly and romantic connections with real people.', 'landing1-155897', NULL);
INSERT INTO `landing_lang` (`id`, `lang_id`, `theme`, `text`, `preset`, `page`) VALUES ('8', '1', 'landing1', '\r\nnetwork users', 'landing1-155897', NULL);
INSERT INTO `landing_lang` (`id`, `lang_id`, `theme`, `text`, `preset`, `page`) VALUES ('9', '1', 'landing1', 'Easy to make new friends', 'landing1-155897', NULL);
INSERT INTO `landing_lang` (`id`, `lang_id`, `theme`, `text`, `preset`, `page`) VALUES ('10', '1', 'landing1', 'Play our popular Discovery game and get matched with other users. \"Like\" is a great way to break the ice and chat with new people.', 'landing1-155897', NULL);
INSERT INTO `landing_lang` (`id`, `lang_id`, `theme`, `text`, `preset`, `page`) VALUES ('11', '1', 'landing1', 'Interesting people nearby', 'landing1-155897', NULL);
INSERT INTO `landing_lang` (`id`, `lang_id`, `theme`, `text`, `preset`, `page`) VALUES ('12', '1', 'landing1', 'Find remarkable people on your city map, get in touch and have a great time together!', 'landing1-155897', NULL);
INSERT INTO `landing_lang` (`id`, `lang_id`, `theme`, `text`, `preset`, `page`) VALUES ('13', '1', 'landing1', 'Stay in touch wherever you go with our apps', 'landing1-155897', NULL);
INSERT INTO `landing_lang` (`id`, `lang_id`, `theme`, `text`, `preset`, `page`) VALUES ('14', '1', 'landing1', 'The application is free to download.', 'landing1-155897', NULL);

DROP TABLE IF EXISTS `mobile_themes`;
CREATE TABLE `mobile_themes` (
  `theme` varchar(45) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `screenshot` varchar(255) DEFAULT NULL,
  `price` int(7) DEFAULT '0',
  `installed` int(1) DEFAULT '0',
  PRIMARY KEY (`theme`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
INSERT INTO `mobile_themes` VALUES ('mobile', 'Belloo', null, '0', '1');
INSERT INTO `mobile_themes` VALUES ('twigo', 'Twigo', null, '199', '0');