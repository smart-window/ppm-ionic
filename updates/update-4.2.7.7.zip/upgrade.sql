INSERT INTO `activity` (a_type,uid,title,message) VALUES ('system', '0', 'Software UPDATE', 'Softawre updated successfully');
INSERT INTO `users_premium` (`uid`, `premium`) VALUES ('1', '0');