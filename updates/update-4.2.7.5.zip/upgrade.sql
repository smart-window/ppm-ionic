INSERT INTO `activity` (a_type,uid,title,message) VALUES ('system', '0', 'Software UPDATE', 'Softawre updated successfully');
ALTER TABLE `landing_lang` MODIFY COLUMN `preset`  varchar(55) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL AFTER `text`, DROP PRIMARY KEY, ADD PRIMARY KEY (`id`, `lang_id`, `theme`, `preset`);

INSERT INTO `app_lang` (`id`, `lang_id`, `text`) VALUES ('285', '1', 'You have');