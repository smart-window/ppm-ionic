<?php
function getData($table,$col,$filter=''){
    global $mysqli;
    $q = $mysqli->query("SELECT $col FROM $table $filter");
    $result = 'noData';
    if($q->num_rows >= 1) {
        $r = $q->fetch_object();
        $result = $r->$col;
    }
    return $result;
}

$checkAdmin = getData('users_notifications','uid','WHERE uid = 1');
if($checkAdmin == 'noData'){
    $mysqli->query("INSERT INTO users_notifications (uid, visit, match_me, fan, near_me, message) VALUES (1,'1,1,1', '1,1,1', '1,1,1', '1,1,1', '1,1,1')");   
}

